<a href="{{$href}}"
        class="rounded-md border border-slate-300 text-black hover:bg-slate-100 shadow-sm text-sm font-semibold text-center bg-white px-2.5 py-1.5"
        >{{$slot}}</a>