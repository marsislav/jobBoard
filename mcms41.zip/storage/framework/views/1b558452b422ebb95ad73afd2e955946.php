<div class="rounded-md border px-2 py-1">
  <?php echo e($slot); ?>

</div><?php /**PATH C:\laragon\www\mcms41\resources\views/components/tag.blade.php ENDPATH**/ ?>