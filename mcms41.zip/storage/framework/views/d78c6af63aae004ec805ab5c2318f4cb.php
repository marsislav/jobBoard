<div>
  <label for="<?php echo e($name); ?>" class="mb-1 flex items-center">
    <input type="radio" name="<?php echo e($name); ?>" value=""
      <?php if(!request($name)): echo 'checked'; endif; ?> />
    <span class="ml-2">All</span>
  </label>

  <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <label for="<?php echo e($name); ?>" class="mb-1 flex items-center">
      <input type="radio" name="<?php echo e($name); ?>" value="<?php echo e($option); ?>"
        <?php if($option === request($name)): echo 'checked'; endif; ?> />
      <span class="ml-2"><?php echo e($option); ?></span>
    </label>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laragon\www\mcms41\resources\views/components/radio-group.blade.php ENDPATH**/ ?>