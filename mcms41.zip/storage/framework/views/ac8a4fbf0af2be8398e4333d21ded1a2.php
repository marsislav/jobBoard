<article
  <?php echo e($attributes->class(['rounded-md border border-slate-300 bg-white p-4 shadow-sm'])); ?>>
  <?php echo e($slot); ?>

</article><?php /**PATH C:\laragon\www\mcms41\resources\views/components/card.blade.php ENDPATH**/ ?>