<nav>
  <ul class="flex space-x-4 text-slate-500">
    <li>
      <a href="/">Home</a>
    </li>

    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>→</li>
      <li>
        <a href="<?php echo e($link); ?>">
          <?php echo e($label); ?>

        </a>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</nav><?php /**PATH C:\laragon\www\mcms41\resources\views/components/breadcrumbs.blade.php ENDPATH**/ ?>